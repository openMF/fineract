/*
 * This program is free software; you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License, version 2.1 as published by the Free Software
 * Foundation.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * program; if not, you can obtain a copy at http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html
 * or from the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * Copyright (c) 2001 - 2013 Object Refinery Ltd, Hitachi Vantara and Contributors..  All rights reserved.
 */

package org.pentaho.reporting.engine.classic.core.metadata;

import org.pentaho.reporting.engine.classic.core.DataFactory;
import org.pentaho.reporting.engine.classic.core.DataRow;
import org.pentaho.reporting.libraries.resourceloader.ResourceManager;

import java.io.Serializable;

public interface DataFactoryCore extends Serializable {
  public String[] getReferencedFields( DataFactoryMetaData metaData, DataFactory element, String query,
      final DataRow parameter );

  public ResourceReference[] getReferencedResources( DataFactoryMetaData metaData, DataFactory element,
      ResourceManager resourceManager, String query, final DataRow parameter );

  public String getDisplayConnectionName( final DataFactoryMetaData metaData, final DataFactory dataFactory );

  public Object getQueryHash( DataFactoryMetaData dataFactoryMetaData, DataFactory dataFactory, String queryName,
      final DataRow parameter );
}
